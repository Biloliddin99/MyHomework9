package com.example.myhomework9.models

data class User(
    val name: String,
    val number: String
)
